# Deploy your dashboard — step by step

## Files to upload to GitHub (3 files)
1. index.html
2. manifest.json
3. sw.js

---

## Step 1 — Upload the files

1. Go to: github.com/mehdisaid-creator/mehdi-dashboard
2. Click **Add file** → **Upload files**
3. Drag all 3 files onto the upload area
4. Scroll down, click **Commit changes**

---

## Step 2 — Enable GitHub Pages

1. Still on your repo page, click **Settings** (top tabs)
2. Scroll down to **Pages** in the left sidebar
3. Under **Branch**, select **main**
4. Folder: **/ (root)**
5. Click **Save**
6. Wait 2 minutes

---

## Step 3 — Your app URL

https://mehdisaid-creator.github.io/mehdi-dashboard/

---

## Step 4 — Add to iPhone home screen

1. Open that URL in Safari (must be Safari, not Chrome)
2. Tap the Share button (box with arrow)
3. Scroll down → **Add to Home Screen**
4. Name it: Mehdi
5. Tap **Add**

It now appears on your home screen like a native app.
Full screen, no browser bar, works offline.

---

## Updating numbers in future

Open the app → go to Money tab → tap the savings number and type the new one.
Goals tick on/off and save automatically.
Everything else updates itself.

For bigger changes (new property, new job) — just come back to Claude.
